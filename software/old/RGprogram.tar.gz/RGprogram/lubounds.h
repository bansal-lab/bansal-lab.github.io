
/************************************ 

  Vikas Bansal created: Mar 2004

Purpose:   functions for computing the lower bounds R_h and R_s and 
for reading in haplotype files  and manipulation 

 ************************************/


#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "rand1.c"

#define DEBUG


int convert(char* temp_string,int length);
// Recursively generate the banker's sequence. // generates all sequences of length "positions"
void generate(int string[], int position, int positions,int* seq, int* curr);
// the first bit in the row vector represents the first row and so on // however they are printed in the reverse order so the last bit printed is the first row 
void init_vector(char* row_vector, int index,int rows,int* nonzero);
int length=0;
int rs_bound(char** matrix, int rows,int cols);



void all_redundant_rows(char** matrix, int rows, int cols, char* row_vector, char* red_row_vector); 
int is_different_hap(char** matrix,char* row_vector, char* hap,int rows, int cols);
// to check if a row is different from a set of haplotypes in a non-informative column 
int is_redundant_row(char** matrix, int rows, int cols, char* row_vector, char rooted,int h);
int redundant_row(char** matrix, int rows, int cols, char* row_vector, char rooted);
int is_red_hap(char** matrix, int rows, int sc, int ec,int cols);



// computing the minimum number of recombination intermediates not exact but upper bound according to R_s
int min_intermediate(char** matrix,char* row_vector, char* hap,int rows, int cols);
// computing the minimum number of recombination intermediates // the exact number
int rooted_rs_bound(char** matrix, int rows,int cols);
// R_sm bound for computing the R_s bound for haplotype matrix with missing data
int rsm_bound(char** matrix, int rows,int cols,char rooted ); // rs bound for missing data 
int mosaic_bound(char** matrix, int rows,int cols );
int incorrect_ri_bound(char** matrix, int rows,int cols);
int new_ri_bound(char** matrix, int rows,int cols );
int ri_bound(char** matrix, int rows,int cols );


// for computing R_h bound //

int test_cover_greedy(char** matrix, int n, int m);
int remove_dups(char** matrix, int rows, int sc, int ec, char** nr_matrix);
void comb_local(char** matrix, int rows, int** R, int** B, int cols, int size);
		  // remove all duplicate rows from the matrix and return them in the matrix nr_matrix
		  // both these matrices are already created 
int clean_redundant(char** matrix, int rows, int sc, int ec, char** nr_matrix,int* nr, int* nc);
		  // remove all duplicate rows, non informative columns until the matrix is clean 
		  // also remove one of two adjacent columns if they have only 2 distinct pairs ( either identical/complementary);

// for computing R_h bound //



int conflict_graph(char** matrix, int rows ,int cols);
		  // finds the bound using the conflict graph which is always better than R_m (the oldest bound);
		  // lets compute the conflict graph 
		  // make the first row all zeros and flip the rest





// converts from non-binary format to binary and also takes care of all types of missing data
// some columns may also contain 0 and 1's so it is best to not change the column at all 
// the data from PHASE contains some columns with I/D as the rare and the frequen allele
// the program below also takes care of such columns 
// if some columns is completely missing it is best to ignore such a column 
// the function also writes the new binary clean matrix to a datafile


void read_genotypes_lpl(char** matrix, int rows,int cols);
void hap_binary(char** matrix, int rows, int cols, char* bfile);
		  // if a column contains more than 2 types, for example 0,1, I etc or A,C,G change all of it 0, i.e don't use that information, don't delete a column, just change to all zeros

// converts the haplotype data from the ACTG format of program PHASE along with I/D/G to binary data
// keeps the missing entries as X
void convert_binary(char** matrix, int rows, int cols);


void read_gabriel(char* genfile);
void read_mhc(char* mhcfile);
void modify(char** matrix, int rows, int cols);
void read_chrom20(char* filename, char* snpfile);
void read_sequences(char* sfile);

void tap_plot_bounds(int** Rh, int** Rs, int cols, FILE* fp1, FILE* fp2, FILE* fp3);
void lpl_plot_bounds(int** Rh, int** Rs, int cols, FILE* fp1, FILE* fp2, FILE* fp3);
void plot_bounds(int** Rh, int** Rs, int cols, FILE* fp1, FILE* fp2, FILE* fp3);

int row_redundant(char** matrix, int rows, int cols, char* row_vector, char rooted,int h,int root);


// check if given row 'h' is consistent with a perfect phylogeny with the existing rows in matrix
// given a root as well

int row_redundant(char** matrix, int rows, int cols, char* row_vector, char rooted,int h,int root)
{
      // row vector gives information about which rows are to be considered
      char* is_col = (char*)malloc(cols);
      int temp=0, ones =0, zeros=0, cols_deleted =0, i=0, j=0;
      int flag =0, flag1=0, r1 =0;
      int k=0;      int l=0;
//			for (i=0;i<rows;i++) printf("%c ",row_vector[i]); printf("\n");

      for (temp=0;temp<cols;temp++) is_col[temp] = '1';

      for (i=0;i<cols;i++)
      {
            ones = 0;  zeros = 0;
            for (j=0;j<rows;j++)
            {
                  if (row_vector[j] == '1' && matrix[j][i] == '0') zeros++;
                  if (row_vector[j] == '1' && matrix[j][i] == '1') ones++;
            }

                  if (zeros == 0 || zeros ==1 || ones == 0 || ones == 1)
                  {
                        is_col[i] = '0';
                        cols_deleted = 1;
                  }
      }
      // printf(" rows; %d cols: %d \n",rows,cols);
      //      if (cols_deleted == 0) return -1; // no column can be deleted

   // now check if there is a row which is identical to row 'h'  in the non-deleted columns
      for ( i=0;i<rows;i++)
      {
            if (row_vector[i] == '1' && i != h)
            {
                  flag1=0;     k =0;
                  while(k<cols)
                  {
                        if ( is_col[k]=='1' && matrix[i][k] != matrix[h][k])
                        {
                              flag1 =1;       // row i is not equal to row h
                              k=cols+1;
                        }
                        k++;
                  }
                  if (flag1 ==0)
                  {
      //                  printf("row %d %s is same as \nrow %d %s \n",i,matrix[i],h,matrix[h]);
                        flag =1;
												row_vector[h] = '1';
                        j = rows; 
                        free(is_col);
                        return 1;
                  }
            }
      }
                        free(is_col);
      return -1; // didnt find redundant row
}



// converts from non-binary format to binary and also takes care of all types of missing data
// some columns may also contain 0 and 1's so it is best to not change the column at all 
// the data from PHASE contains some columns with I/D as the rare and the frequen allele
// the program below also takes care of such columns 
// if some columns is completely missing it is best to ignore such a column 
// the function also writes the new binary clean matrix to a datafile


void hap_binary(char** matrix, int rows, int cols, char* bfile)
{
		  // if a column contains more than 2 types, for example 0,1, I etc or A,C,G change all of it 0, i.e don't use that information
		  // don't delete a column, just change to all zeros
		  //	FILE* fp = fopen(bfile,"w");
		  char firstchar;
		  int first=0;
		  int found = 0,j=0,i=0;
		  char* delete_col = (char*)malloc(cols); // if the column needs to be deleted 
		  int new_cols=cols;

		  for (j=0;j<cols;j++)
		  {
					 delete_col[j] = '0';
					 first = 0;
					 found = 0;
					 // find the first non-missing entry of each column 
					 while (found ==0 && first <rows)
					 {
								if (matrix[first][j] != 'x' && matrix[first][j] != 'X' && matrix[first][j] != '-' && matrix[first][j] != '?')
								{
										  firstchar = matrix[first][j];
										  found =1;
								}
								else
								{
										  matrix[first][j] = '-';
										  first++;
								}
					 }
					 if (first == rows) // the whole column is all missing entries so needs to be removed
					 {
								delete_col[j] = '1'; 
								new_cols--;
					 }

					 else
					 {

								if (firstchar == '1' || firstchar == '0')
								{
										  for ( i=first;i<rows;i++)
										  {
													 if(matrix[i][j] == firstchar)
																matrix[i][j] = '0';
													 else if (matrix[i][j] == 'x' || matrix[i][j] == 'X' || matrix[i][j]== '-' || matrix[i][j] == '?')
																matrix[i][j] = '-';
													 else matrix[i][j] = '1';
										  }
								}
								else
								{
										  for (i=first;i<rows;i++)
										  {
													 if(matrix[i][j] == firstchar)
																matrix[i][j] = '0';
													 else if (matrix[i][j] == 'x' || matrix[i][j] == 'X' || matrix[i][j]== '-' || matrix[i][j] == '?')
																matrix[i][j] = '-';
													 else matrix[i][j] = '1';

										  }

								}
					 }
		  }
		  printf("%d %d \n",rows,new_cols);
		  for (i=0;i<rows;i++)
		  {
					 for (j=0;j<cols ;j++)
					 {
								if (delete_col[j] == '0')
								{
										  printf("%c",matrix[i][j]);
								}
					 }
					 printf("\n");
		  }	

		  free(delete_col);
}

