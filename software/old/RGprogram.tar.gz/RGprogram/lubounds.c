/************************************ 
	Vikas Bansal created: Mar 2004 modified june 2005 purely in C

Purpose:   functions for computing the lower bounds R_h and R_s and for reading in haplotype files  and manipulation 
 ************************************/

#include "lubounds.h"
//#define DEBUG
#undef DEBUG
#define INFTY 10000
//#define PRINT

int size_seed_set = 4;
int greedy_upper_bound(char** matrix, int rows, int cols,int mss);
int composite_bound(char** matrix, int rows,int cols, int width, char* option);
int conflict_free_columns(char** matrix, int rows ,int cols,char* is_col);

int convert(char* temp_string,int length)
{
				// MSB is position 0
				int integer=0, i=0;
				for (i=0;i<length;i++)
				{
								if(temp_string[i] == '0')			integer = integer*2;
								else if (temp_string[i] == '1')	integer = integer*2 +1;
				}
				return integer;
}

// Recursively generate the banker's sequence. // generates all sequences of length "positions"

void generate(int string[], int position, int positions,int* seq, int* curr)
{
				int i=0, a=0, index=0;
				char* temp_string = (char*) malloc(length);
				if (position < positions)
				{
								if (position == 0)
								{
												for (i = 0; i < length; i++)
												{
																string[position] = i;
																generate(string, position + 1, positions,seq,curr);
												}
								}
								else
								{
												for (i = string[position - 1] + 1; i < length; i++)
												{
																string[position] = i;
																generate(string, position + 1, positions,seq,curr);
												}
								}
				}
				else
				{
								//    printf(" new string is output here: "); // output(string, positions);
								for (i = 0; i < length; i++)
								{
												if ((index < position) && (string[index] == i))	  {temp_string[i] = '1';index++;}
												else	  temp_string[i] = '0';
								}

								a = convert(temp_string,length); seq[(*curr)] = a;
								//   printf("%s seq[%d] = %d",temp_string, (*curr), a);
								(*curr)++;
				}
				free(temp_string);
}


// the first bit in the row vector represents the first row and so on // however they are printed in the reverse order so the last bit printed is the first row 

void init_vector(char* row_vector, int index,int rows,int* nonzero)
{
				int temp = index, k=0;
				int selected=0;
				//  printf(" row vector:");
				for ( k=rows-1;k>=0;k--)
				{
								row_vector[k] = index % 2; row_vector[k] += 48;
								if (row_vector[k] == '1')		selected++;
								//    printf(" row[%d] : %c ",k,row_vector[k]);
								index = index/2;
				}
				(*nonzero) = selected;
}

void all_redundant_rows(char** matrix, int rows, int cols, char* row_vector, char* red_row_vector) 
{ 	
				// finds all redundant rows in a given incomplete matrix
				// row vector gives information about which rows are to be considered 
				char* is_col = (char*)malloc(cols);
				//char* red_row_vector = new char[rows];

				int temp=0;
				for (temp=0;temp<cols;temp++) is_col[temp] = '1';
				for (temp=0;temp<rows;temp++) red_row_vector[temp] = '0';

				int ones = 0, zeros = 0, i=0,j=0;
				int cols_deleted=0;    

				//printf(" rows; %d cols: %d \n",rows,cols);
				for (i=0;i<cols;i++)
				{
								ones = 0;
								zeros = 0;

								for ( j=0;j<rows;j++)
								{
												if (row_vector[j] == '1')
												{
																if (matrix[j][i] == '0') zeros++;
																if (matrix[j][i] == '1') ones++;

																//if (matrix[j][i] == '-' || matrix[j][i] == '?') { // do nothing since if a column is non-informative 
																// by ignoring the missing entries it is ok }
												}
								}
								if (zeros == 0 || zeros ==1 || ones == 0 || ones == 1)
								{
												is_col[i] = '0';
												cols_deleted = 1;
								}
				}
				// printf(" rows; %d cols: %d \n",rows,cols);
				//	if (cols_deleted == 0) { delete[] is_col; return -1;} // no column can be deleted 
				// this needs to be checked if we should return -1 or not ?????????????????????///

				// now check if there are two rows which are same in the non-deleted columns 
				int flag =0;
				int flag1=0;
				int r1 =0;
				int k=0;
				int l=0;
				int rows_deleted =0;
				int red_row;
				for ( i=0;i<rows-1;i++)
				{
								if (row_vector[i] == '1')
								{
												flag =0;
												j =i+1;
												while (j<rows)
																// compare row i against all rows below it and if it does not exist then set its flag to true else set to false 
												{
																if (row_vector[j] == '1')
																{
																				flag1=0;
																				k =0;
																				while(k<cols)
																				{
																								if ( is_col[k]=='1' && matrix[i][k] != matrix[j][k] && (matrix[i][k] !='-' || matrix[i][k] != '?') && (matrix[j][k]!= '-'|| matrix[j][k] != '?') )
																								{
																												flag1 =1;       // row i is not equal to row j 
																												k=cols+1;
																								}
																								k++;
																				}
																				if (flag1 ==0)
																				{
																								//        printf(" row %d is same as row %d \n",i,j);
																								flag =1;
																								j = rows;
																								red_row = i;
																								red_row_vector[i] = '1';
																								red_row_vector[j] = '1'; // both i and j are redudnant individually 
																								// is_row[i] = false;
																								rows_deleted = 1;
																				}
																				j++;
																}
																else j++;
												}
								}
				}
				free(is_col);
}

// to check if a row is different from a set of haplotypes in a non-informative column 

int is_different_hap(char** matrix,char* row_vector, char* hap,int rows, int cols)
{
				// row_vector tells which of the rows of the matrix are to be considered
				// hap is the haplotype to be considered
				char* col_vector = (char*) malloc(cols);
				int zeros=0, ones=0,c=0,r=0;

				for (c=0;c<cols;c++)
				{
								col_vector[c] = '1';
								zeros=0;
								ones=0;
								for (r=0;r<rows;r++)
								{
												if(row_vector[r] == '1' )
												{
																if(matrix[r][c] == '0') zeros++;
																else if (matrix[r][c] == '1') ones++;
																//else 
																//printf("error non binary matrix\n\n");
												}
								}

								// we have the count of zeros and ones      
								// row is different if in some column all others are identical and it is rare allele                                                                                                                                     
								if ((ones == 0 && hap[c] == '1') ||  (zeros == 0 && hap[c] == '0'))
								{
												free(col_vector);
												return 1;
								}
				}
				free(col_vector);
				return 0;

}


int is_redundant_row(char** matrix, int rows, int cols, char* row_vector, char rooted,int h)
{
				// row vector gives information about which rows are to be considered
				char* is_col = (char*)malloc(cols);
				int temp=0;
				for (temp=0;temp<cols;temp++) is_col[temp] = '1';

				int ones = 0,zeros = 0, cols_deleted=0,i=0,j=0;
				for ( i=0;i<cols;i++)
				{
								ones = 0;
								zeros = 0;

								for (j=0;j<rows;j++)
								{
												if (row_vector[j] == '1')
												{
																if (matrix[j][i] == '0') zeros++;
																if (matrix[j][i] == '1') ones++;

												}
								}

								if (rooted =='r')
								{
												if (matrix[0][i] == '0')
												{
																if (ones == 0 || ones == 1)
																{
																				is_col[i] = '0';
																				cols_deleted = 1;

																}
												}
												else if (matrix[0][i] == '1')
												{
																if (zeros ==0 || zeros ==1)
																{
																				is_col[i] = '0';
																				cols_deleted = 1;
																}
												}

								}
								else
								{
												if (zeros == 0 || zeros ==1 || ones == 0 || ones == 1)
												{
																is_col[i] = '0';
																cols_deleted = 1;
												}
								}
				}
				// printf(" rows; %d cols: %d \n",rows,cols);
				//      if (cols_deleted == 0) return -1; // no column can be deleted

				// now check if there is a row which is identical to row 'h'  in the non-deleted columns
				int flag =0;
				int flag1=0;
				int r1 =0;
				int k=0;
				int l=0;
				for ( i=0;i<rows;i++)
				{
								if (row_vector[i] == '1' && i != h)
								{
												flag1=0;
												k =0;
												while(k<cols)
												{
																if ( is_col[k]=='1' && matrix[i][k] != matrix[h][k] && matrix[i][k]!= '-' && matrix[h][k]!= '-' && matrix[h][k]!= '?' &&
																								matrix[i][k]!= '?' )
																{
																				flag1 =1;       // row i is not equal to row h
																				k=cols+1;
																}
																k++;
												}
												if (flag1 ==0)
												{
																//        printf(" row %d is same as row %d \n",i,j);
																flag =1;
																j = rows;
																free(is_col);
																return 1;
												}
								}
				}
				free(is_col);
				return -1; // didnt find redundant row
}




// rooted version of R_S/R_I can simply be implemented: assumption is that the first row is the root

int redundant_row(char** matrix, int rows, int cols, char* row_vector, char rooted)
{
				// row vector gives information about which rows are to be considered 
				char* is_col = (char*)malloc(cols);

				int temp=0;
				for (temp=0;temp<cols;temp++) is_col[temp] = '1';

				int ones = 0, zeros = 0, i=0,j=0;
				int cols_deleted=0;    
				//printf(" rows; %d cols: %d \n",rows,cols);
				for (i=0;i<cols;i++)
				{
								ones = 0;
								zeros = 0;
								for (j=0;j<rows;j++)
								{
												if (row_vector[j] == '1')
												{
																if (matrix[j][i] == '0') zeros++;
																if (matrix[j][i] == '1') ones++;

												}
								}

								if (rooted =='r')
								{
												if (matrix[0][i] == '0')
												{
																if (ones <= 1)
																{
																				is_col[i] = '0';
																				cols_deleted = 1;

																}
												}
												else if (matrix[0][i] == '1')
												{
																if (zeros  <= 1)
																{
																				is_col[i] = '0';
																				cols_deleted = 1;
																}
												}

								}
								else
								{
												if (zeros == 0 || zeros ==1 || ones == 0 || ones == 1) 
												{
																is_col[i] = '0'; 
																cols_deleted = 1;
												}
								}
				}
				// printf(" rows; %d cols: %d \n",rows,cols);
				if (cols_deleted == 0) { free(is_col); return -1; } // no column can be deleted 

				// now check if there are two rows which are same in the non-deleted columns 
				int flag =0;
				int flag1=0;
				int r1 =0;
				int k=0;
				int l=0;
				int rows_deleted =0;
				int red_row;
				for ( i=0;i<rows-1;i++)
				{
								if (row_vector[i] == '1')
								{
												flag =0;
												j =i+1;
												while (j<rows)
																// compare row i against all rows below it and if it does not exist then set its flag to true else set to false 
												{
																if (row_vector[j] == '1')
																{
																				flag1=0;
																				k =0;
																				while(k<cols)
																				{
																								if ( is_col[k]=='1' && matrix[i][k] != matrix[j][k] && matrix[i][k]!= '-' && matrix[j][k]!= '-' && matrix[i][k]!= '?' &&
																																matrix[j][k]!= '?' )
																								{
																												flag1 =1;       // row i is not equal to row j 
																												k=cols+1;
																								}
																								k++;
																				}
																				if (flag1 ==0)
																				{
																								//        printf(" row %d is same as row %d \n",i,j);
																								flag =1;
																								j = rows;
																								red_row = i;
																								// is_row[i] = false;
																								rows_deleted = 1;
																								free(is_col);
																								return red_row;
																				}
																				j++;
																}
																else j++;
												}
								}
				}
				free(is_col);
				return -1; // didnt find redundant row 
}


int rs_bound(char** matrix, int rows,int cols )
{

				if (rows > 18 ) return 0; // maximum number of rows allowed is 20 
				int size = pow(2,rows); int i=0; int* string;
				int* sequence = (int*)malloc(sizeof(int)*size); int* rs_table = (int*)malloc(size*sizeof(int));
				int* backtrack = (int*)malloc(sizeof(int)*size); // for each entry in the rs table where does it point to in backtracking 
				for (i=0;i<size;i++)
								rs_table[i] = -10;
#ifdef DEBUG
				printf("rows: %d \n",rows);
				printf("  table size: %d \n",size);
#endif
				int current = 0; length = rows;

				for (i = 0; i <= rows; i++)
				{
								string = (int*)malloc(sizeof(int)*rows);
								generate(string, 0, i, sequence, &current);
								free(string);
				}

				char* row_vector = (char*)malloc(rows);
				for ( i=0;i<rows;i++)	 row_vector[i] = '0';
				int red_row ;  int selected =0; int previous;  int min; int h;  int best, iter=0;

				for(iter=1;iter<size;iter++)
				{
								//   printf("iter: %d %d\n",iter,sequence[iter]);
								init_vector(row_vector,sequence[iter],rows,&selected);
								if (selected >3)
								{ 
												red_row = redundant_row(matrix,rows,cols,row_vector,'u');
												if (red_row != -1)
												{
																row_vector[red_row] = '0'; previous = convert(row_vector,rows);
																rs_table[sequence[iter]] = rs_table[previous];
																backtrack[sequence[iter]] = previous;
																//     printf(" red row: %d no recomb %d  %d \n",red_row,rs_table[sequence[iter]],previous); 
												}
												else if (red_row == -1)
												{
																min =1000; best =0;

																for (h=0;h<rows;h++)
																{
																				if (row_vector[h] == '1')
																				{
																								row_vector[h] = '0';
																								previous = convert(row_vector,rows);
																								if (rs_table[previous] <0)
																								{
																												printf("value of previous : %d %d \n",previous,rs_table[previous]);
																												getchar();
																								}
																								if (rs_table[previous] < min)
																								{
																												min = rs_table[previous];
																												best = previous;
																								}
																								row_vector[h] = '1';

																				}
																}
																//printf(" value of min :%d\n",min);
																rs_table[sequence[iter]] = min +1;
																backtrack[sequence[iter]] = best;
																// recombination add 1 
																// min _h R_s(H-h)
																//                printf(" need to add recomb %d  \n",rs_table[sequence[iter]]);
																//if (rs_table[sequence[iter]] > 2)
																//getchar();
												}
								}
								else
								{
												rs_table[sequence[iter]] = 0;
												backtrack[sequence[iter]] = 0;
												// printf(" rs_table[%d] : %d \n",sequence[iter], rs_table[sequence[iter]]);
												// getchar();
								}
				}
				int recombs = rs_table[sequence[size-1]];

				free(sequence); free(row_vector); free(rs_table); free(backtrack);
				return recombs;

}
// computing the minimum number of recombination intermediates // the exact number

int min_intermediate_exact(char** matrix,char* rv, char* hap,int rows, int cols,int h)
{
				// row_vector tells which of the rows of the matrix are to be considered
				// hap is the haplotype to be explained
				char* col_vector = (char*)malloc(cols);
				char* row_vector = (char*)malloc(rows);

				int riter=0, citer=0,c=0,r=0,l=0;
				int flag =0, flag1=0 , j=0, rows_deleted = 0, cols_deleted = 0, r1=0, i=0, k=0;
				int diffbase = 0;
				int zeros=0, ones=0;
				int nr=0, nc=cols; // reduced number of rows and cols resp.
				int reductions =1;
				int min;

				for ( i=0;i<rows;i++) row_vector[i] = rv[i];
				for ( c=0;c<cols;c++)    col_vector[c] = '1';

				while (reductions >0)
				{
								reductions = 0;
								for (i=0;i<rows-1;i++)
								{
												if (row_vector[i] !='1') continue; 
												for (j=i+1;j<rows;j++)
												{
																if (row_vector[j] !='1') continue; 	
																diffbase = 0;
																for (k=0;k<cols;k++) { if (col_vector[k] =='1' && matrix[i][k] != matrix[j][k]) { diffbase =1; break; } }
																if (diffbase ==0) { row_vector[j] ='0'; reductions++;}
												}
								}

								for (j=0;j<cols;j++) 
								{
												if (col_vector[j] =='0') continue;
												zeros = 0; ones=0; if (matrix[h][j] =='1') ones++; else zeros++;
												for (i=0;i<rows;i++) { if (row_vector[i] =='1' && matrix[i][j] =='1') ones++; else if (row_vector[i] =='1' && matrix[i][j] =='0') zeros++;}
												if (zeros < 2 || ones < 2)  { col_vector[j] ='0'; reductions++;}
								}

				}

				nc =0; nr=0;
				for (i=0;i<rows;i++) { if(row_vector[i] =='1') nr++;}
				for (i=0;i<cols;i++) { if(col_vector[i] =='1') nc++;}

				if (nc == 0 || nr ==0 ) { return 0;}

				// while loop for doing the row and column deletion ends

				if (nc == 0 || nr ==0 ) { printf(" raise error flag \n"); getchar();}
				char** red_matrix = (char**)malloc(sizeof(char*)*nr);
				for (r =0;r<nr;r++)
								red_matrix[r] = (char*)malloc(nc);
				char* red_hap = (char*)malloc(nc);
				// copy the relevant matrix and haplotype
				for (r=0;r<rows;r++)
				{
								if(row_vector[r] == '1')
								{
												citer=0;
												for(c=0;c<cols;c++)
												{
																if(col_vector[c] == '1')
																{
																				red_matrix[riter][citer] = matrix[r][c];
																				citer++;
																}
												}
												riter++;
								}
				}
				citer=0;
				for( c=0;c<cols;c++)
				{
								if(col_vector[c] == '1')
								{
												red_hap[citer] = hap[c];
												citer++;
								}
				}

				// the real code for computing recombination intermediates
				int** I = (int**)malloc(sizeof(int*)*nc); // I[c,r] = min no of recombinations needed to explain the first c cols of hap such that the cth col arsoe from haplotype r
				for (c=0;c<nc;c++)
				{
								I[c] = (int*)malloc(sizeof(int)*nr);
								for(r=0;r<nr;r++)
												I[c][r] = 0;
				}

				for (c=0;c<nc;c++)
				{
								for (r=0;r<nr;r++)
								{
												if(c==0)
												{
																if(red_hap[c] == red_matrix[r][c] || red_hap[c] == '?' || red_hap[c] == '-')
																				I[c][r] = 0;
																else I[c][r] = INFTY;
												}
												else
												{

																if(( red_hap[c] == red_matrix[r][c]) || (red_hap[c] == '?') || (red_hap[c] == '-'))
																{
																				min = I[c-1][r];
																				// compute the minimum
																				for (l=0;l<nr;l++)
																				{
																								if ((1 + I[c-1][l]) < min)
																												min = 1 + I[c-1][l];
																				}
																				I[c][r] = min;
																}
																else
																				I[c][r] = INFTY;
												}
								}
				}
				min = I[nc-1][0];
				for (l=1;l<nr;l++){
								if (I[nc-1][l] < min)
												min = I[nc-1][l];}

				free(row_vector); free(col_vector); free(red_hap);
				for (l=0;l<nc;l++) free(I[l]); free(I);
				for (l=0;l<nr;l++) free(red_matrix[l]); free(red_matrix);
				//printf(" value of min recomb is %d \n\n",min);
				return min;
}

int hamming_distance(char* seq1, char* seq2, int length)
{
				int i=0, hd =0;
				for (i=0;i<length;i++) { if (seq1[i] != seq2[i]) hd++;}
				return hd;
}

int min_distance(int** hamming_matrix,char* row_vector,int r,int rows)
{
				int min = 10000, i=0;
				for (i=0;i<rows;i++)
				{
								if (row_vector[i] == '1' && hamming_matrix[r][i] < min) min = hamming_matrix[r][i];
				}
				return min;
}


int greedy_upper_bound1(char** matrix, int rows, int cols,int mss);


int greedy_upper_bound1(char** matrix, int rows, int cols,int mss)
{
				//if (rows < 20) { printf(" calling mosaic bound computation \n"); return mosaic_bound( matrix, rows,cols );}
				//			conflict_graph(matrix,rows,cols); getchar();

				char* row_vector = (char*)malloc(rows);
				int i=0, r=0, j=0;
				for (i=0;i<rows;i++) row_vector[i] = '1';
				char* start = (char*)malloc(cols);
				int start_seq;

				int** hamming_matrix = (int**) malloc(sizeof(int*)*rows);	
				for (i=0;i<rows;i++) { hamming_matrix[i] = (int*)malloc(sizeof(int)*rows); for (j=0;j<rows;j++) hamming_matrix[i][j] = hamming_distance(matrix[i],matrix[j],cols);}	

				int max_size_seed_set = rows/3;
				int min_size_seed_set = rows/6; if (min_size_seed_set < mss) min_size_seed_set = mss;
				int current_size = 1, recomb=0, inter=0 , cs = 0;
				int best_row = 0; int best_recomb = 0, best_distance =0;
				int distance = 0;	
				int best_upper_bound = 10000; int max_dist = 1;

				int seq_added = 0;
				int new_rows = rows;
				int flag =1;
				while (flag ==1)
				{
								flag =0;
								for (r=rows-1;r>=0;r--)
								{
												if (row_vector[r] == '1') 
												{
																row_vector[r] = '0';
																inter = min_intermediate_exact(matrix,row_vector, matrix[r], rows, cols,r);
																if (inter ==1) { new_rows--; recomb++; flag =1;/* for (i=0;i<cols;i++) printf("%c",matrix[r][i]); printf("\n");*/} 
																else row_vector[r] ='1';

												}
								}
				}

				if (new_rows > 18) 
				{
								flag =1;
								while (flag ==0)
								{
												flag =0;
												for (r=rows-1;r>=0;r--)
												{
																if (row_vector[r] == '1') 
																{ 
																				row_vector[r] = '0';
																				inter = min_intermediate_exact(matrix,row_vector, matrix[r], rows, cols,r);
																				if (inter <3) { new_rows--; recomb += inter; flag =1; /*for (i=0;i<cols;i++) printf("%c",matrix[r][i]); printf("\n");*/}
																				else row_vector[r] ='1';

																}
												}
								}
				}

				if (new_rows > 16) 
				{
								//								printf(" removing more recombinants \n");
								flag =1;
								while (flag ==0)
								{
												flag =0;
												for (r=rows-1;r>=0;r--)
												{
																if (row_vector[r] == '1')
																{
																				row_vector[r] = '0';
																				inter = min_intermediate_exact(matrix,row_vector, matrix[r], rows, cols,r);
																				if (inter <6) { new_rows--; recomb += inter; flag =1; //for (i=0;i<cols;i++) printf("%c",matrix[r][i]); printf("\n");
																				}
																				else row_vector[r] ='1';

																}
												}
								}

				}
				int ri=0;
				//				printf(" original rows %d new rows %d recombinations added %d \n",rows,new_rows,recomb);

				char** smaller_matrix = (char**) malloc(sizeof(char*)*new_rows);
				for (i=0;i<new_rows;i++) smaller_matrix[i]= (char*) malloc(cols);

				for (i=0;i<rows;i++) 
				{ 
								if (row_vector[i] =='1') 
								{ 
												for (j=0;j<cols;j++) smaller_matrix[ri][j] = matrix[i][j]; 
												ri++;
								}
				}

				for(i=0;i<new_rows;i++) 
				{ 
								//		for (j=0;j<cols;j++) printf("%c",smaller_matrix[i][j]); 
								//		printf("\n");
				}	

				int mbound = 0;
				free(row_vector); free(start);
				if (new_rows <15) mbound= recomb + mosaic_bound(smaller_matrix,new_rows,cols);
				else	mbound = recomb + greedy_upper_bound(smaller_matrix,new_rows,cols,mss);


				for (i=0;i<new_rows;i++) free(smaller_matrix[i]); free(smaller_matrix);
				for (i=0;i<rows;i++) free(hamming_matrix[i]); free(hamming_matrix);
				return mbound;
}



int greedy_upper_bound(char** matrix, int rows, int cols,int mss)
{
				//				if (rows < 16) { return mosaic_bound( matrix, rows,cols );}
				//      conflict_graph(matrix,rows,cols); getchar();

				char* row_vector = (char*)malloc(rows);
				int i=0, r=0, j=0;
				for (i=0;i<rows;i++) row_vector[i] = '0';
				char* start = (char*)malloc(cols);
				int start_seq;

				int** hamming_matrix = (int**) malloc(sizeof(int*)*rows);
				for (i=0;i<rows;i++) {
								hamming_matrix[i] = (int*)malloc(sizeof(int)*rows);
								for (j=0;j<rows;j++) hamming_matrix[i][j] = hamming_distance(matrix[i],matrix[j],cols);
				}

				int max_size_seed_set = rows/3;
				int min_size_seed_set = rows/6; if (min_size_seed_set < mss) min_size_seed_set = mss; if (min_size_seed_set > 5) min_size_seed_set = 5;
				int current_size = 1, recomb=0, inter=0 , cs = 0;
				int best_row = 0; int best_recomb = 0, best_distance =0;
				int distance = 0;
				int best_upper_bound = 10000; int max_dist = 1;

				int seq_added = 0;
				// for each sequence fixed as root

				/*
					 char* consensus = (char*)malloc(cols); // for each column represents the frequent allele 
					 int* freq = (int*)malloc(sizeof(int)*cols);
					 for (j=0;j<cols;j++)
					 {	
					 freq[j]=0;
					 for (i=0;i<rows;i++) { if (matrix[i][j] =='0') freq[j]++;}
					 if (freq[j] > rows/2) consensus[j]='0'; else consensus[j] = '1';
					 }

					 free(freq);
					 int*			distancevec = (int*)malloc(sizeof(int)* rows);
					 int median_row=0; int min_dist =1000;
					 for (i=0;i<rows;i++)
					 {
					 distancevec[i]=0;
				// compute distance of row 'i' to the consensus
				for (j=0;j<cols;j++) { if(consensus[j] != matrix[i][j]) distancevec[i]++;}
				if (distancevec[i] < min_dist) { median_row = i; min_dist = distancevec[i];}
				}
				 */
				for (r=0;r<rows;r++)
				{
								for (i=0;i<cols;i++) start[i] = matrix[r][i]; // make the row r as root of the ARG
								start_seq = r;

								for (i=0;i<rows;i++) row_vector[i] = '0'; row_vector[start_seq] = '1';  current_size = 1;
								// add all sequences to seed set that are less than 4 mutation apart or one recombination from it
								current_size =1;  max_dist = 1;

								while (current_size < min_size_seed_set && current_size < max_size_seed_set && max_dist < 5)
								{
												for (i=0;i<rows;i++)
												{
																if (row_vector[i] =='0') continue;
																for (j=0;j<rows;j++)
																{
																				if (row_vector[j] =='0' && hamming_matrix[i][j] <= max_dist)
																				{
																								row_vector[j] = '1';
																								if (row_redundant(matrix,rows,cols,row_vector,'n',j,start_seq) == 1)
																								{ /*printf(" sew added %s \n",matrix[j]);*/ row_vector[j] ='1'; current_size++; seq_added = 1;}
																								else row_vector[j] = '0';
																				}
																}
												}
												max_dist++;
								}
								// if size of seed set is less than 5 then add all sequences that are 2-3 mutations apart
								if(current_size < min_size_seed_set)
								{
												for (i=0;i<rows;i++)
												{
																if (row_vector[i] =='0') continue;
																for (j=0;j<rows;j++)
																{
																				if (row_vector[j] =='0' && hamming_matrix[i][j] <= max_dist)
																				{
																								row_vector[j] = '1';
																								if (row_redundant(matrix,rows,cols,row_vector,'n',j,start_seq) == 1)
																								{ /*printf(" sew added %s \n",matrix[j]);*/ row_vector[j] ='1'; current_size++; seq_added = 1;}
																								else row_vector[j] = '0';
																				}
																}
												}
												max_dist++;
								}
								recomb = 0;
								// if seed is big enough, try to add the remaining sequences iteratively in increasing order of number of recombinations/mutations required to add them
								//	printf("current size of seed %s %d\n",matrix[r],current_size); for (i=0;i<rows;i++) {if(row_vector[i] == '1') printf("%s\n",matrix[i]);}
								//	for (i=0;i<cols;i++) printf("-"); printf("\n");

								if (current_size >= min_size_seed_set)
								{
												//					printf("current size of seed %s %d\n",matrix[r],current_size); for (i=0;i<rows;i++) {if(row_vector[i] == '1') printf("%s\n",matrix[i]);}
												//		for (i=0;i<cols;i++) printf("-"); printf("\n");
												while (current_size < rows)
												{
																cs = current_size;
																best_recomb = 100000; best_row = -1;
																for (i=0;i<rows;i++)
																{
																				if (row_vector[i] == '0') 
																				{
																								inter = min_intermediate_exact(matrix,row_vector, matrix[i], rows, cols,i);
																								//		inter = min_intermediate(matrix,row_vector, matrix[i], rows, cols);
																								distance = min_distance(hamming_matrix,row_vector,i,rows);
																								if (distance < (cols/2) && inter < best_recomb)  {best_row = i; best_recomb = inter; best_distance = distance;}
																				}
																}
																if (best_row != -1) {
																				//                 #ifdef PRINT
																				//												printf("%s added to ARG with %d recomb events\n",matrix[best_row],best_recomb);
																				//            #endif
																				row_vector[best_row] ='1'; current_size++; recomb += best_recomb;
																}
																else { recomb = 1000000; break;}

												}
												//            #ifdef PRINT
												//			printf("ARG with root: %s requires at most %d recombs\n\n",matrix[r],recomb);
												//         #endif
												if (recomb < best_upper_bound) best_upper_bound = recomb;
												//	for (i=0;i<rows;i++) {if(row_vector[i] == '1') printf("%s\n",matrix[i]);}

								}
				}

				free(row_vector); free(start);
				//			free(consensus); free(distancevec); free(freq); 
				int fr=0;
				for (fr=0;fr<rows;fr++) free(hamming_matrix[fr]); 
				free(hamming_matrix);

				if (best_upper_bound >1000 && (rows < 16)) return mosaic_bound( matrix, rows,cols ); 
				//	else if (best_upper_bound >1000 && (rows > 15)) return greedy_upper_bound1( matrix, rows,cols,4); 
				else 				return best_upper_bound;
}

int Min_rec (char **list, int x, int size, int nsam)
{  /* Calculate min # rec. events */
				int a, b, c, e, gtest, flag = 0;

				if (size<2 || x >= (size-1))
								return (0);
				for (a=x+1; a<size; ++a) {
								for (b=x; b<a; ++b) {
												gtest = 0;
												for (e=0; e<nsam; ++e)
																if (list[e][b] == '0' && list[e][a] == '0') {
																				++gtest;
																				break;
																}
												for (e=0; e<nsam; ++e)
																if (list[e][b] == '0' && list[e][a] == '1') {
																				++gtest;
																				break;
																}
												for (e=0; e<nsam; ++e)
																if (list[e][b] == '1' && list[e][a] == '0') {
																				++gtest;
																				break;
																}
												for (e=0; e<nsam; ++e)
																if (list[e][b] == '1' && list[e][a] == '1') {
																				++gtest;
																				break;
																}
												if (gtest == 4) {
																flag = 1;
																break;
												}
								}
								if (flag == 1)
												break;
				}
				if (a==size)
								return (0);
				else {
								c = Min_rec (list, a, size, nsam);
								return (1+c);
				}
}


int process_matrix(char** matrix, int rows,int cols,int windowsize,char* boundtype,int* lb, int* ub,int* disrows,int* RM,int* segsites)
{
				int width = windowsize, i=0,j=0,r=0,c=0;

				int ar=0,rh_bound, mosaicbound; float time_taken_rh;
				int gub2=0;

				char** reduced_matrix = (char**)malloc(sizeof(char*)*rows);
				for(i=0;i<rows;i++)   reduced_matrix[i]= (char*)malloc(cols);
				int old_rows = rows, old_cols= cols;
				int H= clean_redundant(matrix,rows,0,cols-1,reduced_matrix,&r,&c);

//				rows = r;
//				cols = c;
				time_t t_start,t_finish;

				if (cols <2 || rows <4) { rh_bound = 0; ar =0; (*RM)=0;}

				else {
								(*RM) = Min_rec(matrix,0,cols,rows);
								rh_bound=composite_bound(matrix,rows,cols,width,boundtype);
								time(&t_start);

								if (rh_bound <2) ar =rh_bound;
								else {
												time(&t_start);
												ar = rh_bound; if (cols >1) ar = (int)ar*100/cols; else ar = 0;
												time(&t_finish);
												time_taken_rh = t_finish- t_start;
								}

								//int gub2 = greedy_upper_bound1(reduced_matrix,rows,cols,4);
				}
				printf(" ---------------------Summary statistics for the sample ---------------\n\n Segsites %d H %d R_M: %d R_H: %d \n",c,H,(*RM),rh_bound);
				(*segsites) = cols; // reduced number of sites 
				(*lb) = rh_bound;  
				if (ar < gub2 && ar !=0 && ar!=1000) (*ub) = ar; else if (gub2!=0) (*ub) = gub2; else (*ub) = ar;
				(*disrows) = H;
				for (i=0;i<old_rows;i++) free(reduced_matrix[i]); free(reduced_matrix);
				return 1; // exit here 

}

int bootstrap_sample(char** matrix,int rows,int cols, int width,char* option,int samplesize,int no_samples)
{
				char** smatrix = (char**)malloc(sizeof(char*)*samplesize);
				int i=0,j=0;
				for (i=0;i<samplesize;i++) smatrix[i] = (char*)malloc(cols);

				double ran1();

				// randomly sample from the input 'matrix' for $no_samples$ times and compute bounds for each sample
				int ranrow;
				int s=0, lb=0,ub=0,rm=0,H=0,ss=0; double lbavg=0, ubavg=0,rmavg=0,Havg=0;
				for (s=0;s<no_samples;s++)
				{
								for (i=0;i<samplesize;i++)
								{
												ranrow = (int)(ran1()*samplesize);
												for (j=0;j<cols;j++) smatrix[i][j] = matrix[ranrow][j];
								}
								process_matrix(smatrix,samplesize,cols,width,option,&lb, &ub,&H,&rm,&ss);
								lbavg +=lb; ubavg += ub; Havg += H; rmavg += rm;

				}
				lbavg /= no_samples; ubavg /= no_samples; rmavg /= no_samples; Havg /= no_samples;
				fprintf(stdout," lbavg %f ubavg %f Ravg %f Havg \n",lbavg,ubavg,rmavg,Havg); 
}

int composite_bound(char** matrix, int rows,int cols, int width, char* option)
{

				//fprintf(stdout,"Computing Composite LOWER BOUNDS \n\n");
				int r_h =0, ub = 0, MIS =0, a=0, i=0, code_to_use =0, y=0, x=0,r_s=0,r_i=0;
				int** Bh; int** Rh; int j=0;

				Bh= (int**) malloc(cols * sizeof(int*));
				for ( i=0;i<cols;i++)
				{
								Bh[i] = (int*)malloc(cols*sizeof(int));
								for (j=0;j<cols;j++)   Bh[i][j] = 0;
				}
				Rh = (int**) malloc(sizeof(int*)*cols);
				for (i=0;i<cols;i++)
				{
								Rh[i] = (int*) malloc(sizeof(int)* cols);
								for (j=0;j<cols;j++)      Rh[i][j] =0;
				}

				time_t t_start,t_finish;
				time(&t_start);


				if (width > cols) width = cols;
				char** submatrix; 
				// first compute the R-h bound and then based on the choice do the other one 

				for (x =0;x< cols-1;x++)
				{
								//				if (x %5 == 0) printf(" done for columns uptil %d\n",x);
								y = x+1;
								while( y < x+width)
								{
												if(y < cols) 
												{
																r_h =0;
																submatrix = (char**) malloc(rows*sizeof(char*));
																for(i=0;i<rows;i++)  submatrix[i]= (char*) malloc((y-x+1)*sizeof(char));

																a = remove_dups(matrix,rows,x,y,submatrix);	// needs to be modified for missing data
																r_h = test_cover_greedy(submatrix,a,y-x+1);     // needs to modified as well 
																//if (a < 16) r_s = rs_bound(submatrix,a,y-x+1); 
																//if (r_s > r_h) r_h = r_s;

																if (y-x+1 > 2 && y-x+1 < width)
																{
																				r_s=0;
																				r_i=0;
																				if (strcmp(option,"ri") == 0) 
																				{
																								r_i = ri_bound(submatrix,a,y-x+1);
																								r_h = r_i;
																				}
																				else if (strcmp(option,"nri") == 0) 
																				{
																								//																			if (x %5 == 0) printf(" done for columns uptil %d\n",y);
																								r_i =new_ri_bound(submatrix,a,y-x+1);
																								if (r_i > r_h) r_h = r_i;
																				}
																				else if (strcmp(option,"new") == 0) 
																				{
																								r_i = rs_bound(submatrix,a,y-x+1);
																								ub = mosaic_bound(submatrix,a,y-x+1);
																								//																		if (r_i < ub && r_i !=0) { printf(" increase in value of LB: %d %d\n",r_i,ub); r_h =r_i+1; }
																				}
																				else if (strcmp(option,"rs") == 0) 
																				{
																								r_s = rs_bound(submatrix,a,y-x+1);
																				}
																				else  
																								r_s = r_h;
																}
																if (r_h > Bh[x][y]) Bh[x][y] = r_h;
																for(i=0;i<rows;i++){
																				free(submatrix[i]);
																}
																free(submatrix);

												}
												y++;
								}
				}

				// also print out the blocks which correspond to this high recombination rate
				comb_local(matrix, rows, Rh, Bh, cols, width);

								printf(" lower bound on number of recombinations is : %d\n",Rh[0][cols-1]);
				time(&t_finish);
				//				printf("\n------Time elapsed------\n");
				//			printf("%ld s\n",t_finish-t_start);

				int rs_bound = Rh[0][cols-1];
				float time_taken_rs = t_finish- t_start;

				/* print summary */
				//		printf(" bounds for the matrix of size %d x %d \n",rows,cols);
				//		printf(" rh bound for the matrix is %d computed in time %f \n",rs_bound,time_taken_rs);

				for (i=0;i<cols;i++){
								free(Rh[i]); free(Bh[i]);}
				free(Rh); free(Bh);
				return rs_bound;
}



// it is actually an upper bound but minimum over all orderings so it shoud be good 

int mosaic_bound(char** matrix, int rows,int cols )
{

				if (rows > 18) return 0;// maximum number of rows allowed is 20 
				//else printf(" rows less than 18, perfroming computation \n");
				int size = pow(2,rows);
				int* sequence = (int*)malloc(sizeof(int)*size);
				int* rs_table = (int*)malloc(sizeof(int)*size);
				int* ri_table = (int*)malloc(sizeof(int)*size);
				int current = 0, i=0;
				// declare table of size 2^rows
				//int* backtrack = new int[size]; // for each entry in the rs table where does it point to in backtracking 
				for (i=0;i<size;i++)
				{
								rs_table[i] = 0;			ri_table[i] = 0;
				}
				length = rows;
				int * string;
				for (i = 0; i <= rows; i++)
				{
								string = (int*)malloc(sizeof(int)*rows);
								generate(string, 0, i, sequence, &current);
								free(string);
				}

				char* row_vector = (char*)malloc(rows);
				for (i=0;i<rows;i++) row_vector[i] = '0';
				int red_row ;
				int selected =0;
				int previous;
				int min,max, mint=0;
				int h;
				int best;
				int last, inter, iter=1;

				for(iter=1;iter<size;iter++)
				{
								//								if (iter %100000 ==0) { 
								//											printf("iter: %d %d\n",iter,sequence[iter]);}
								init_vector(row_vector,sequence[iter],rows,&selected);

								if (selected >3)
								{ 
												red_row = redundant_row(matrix,rows,cols,row_vector,'u');

												//     printf("red_row: %d \n",red_row);
												if (red_row != -1)
												{
																row_vector[red_row] = '0';
																previous = convert(row_vector,rows);
																// for (h=0;h<rows;h++)
																//    printf("%c ",row_vector[h]);
																// printf("\n\n");
																if (rs_table[previous] <0)
																{
																				printf("value of previous : %d %d \n",previous,rs_table[previous]);
																				//getchar();

																}
																rs_table[sequence[iter]] = rs_table[previous];
																ri_table[sequence[iter]] = ri_table[previous];
																//backtrack[sequence[iter]] = previous;
																// no recombination
																//     printf(" red row: %d no recomb %d  %d \n",red_row,rs_table[sequence[iter]],previous); 
												}
												else if (red_row == -1)
												{
																min = INFTY;
																best =0;

																for (h=0;h<rows;h++)
																{
																				if (row_vector[h] == '1')
																				{
																								row_vector[h] = '0';
																								previous = convert(row_vector,rows);
																								if (rs_table[previous] <0)
																								{
																												printf("value of previous : %d %d \n",previous,rs_table[previous]);
																												getchar();
																								}
																								if (rs_table[previous] < min)
																								{
																												min = rs_table[previous];
																												best = previous;
																								}
																								row_vector[h] = '1';

																				}
																}
																//printf(" value of min :%d\n",min);
																rs_table[sequence[iter]] = min +1;
																best =0;
																min = 100000, mint =0;
																// R_I,i = max { (1 + R_I(r-i)), I_i(r-i) + R_s (r-i)}  
																// ri(r) = min_i  R_I,i
																for (h=0;h<rows;h++)
																{
																				if (row_vector[h] == '1')
																				{
																								row_vector[h] = '0';
																								previous = convert(row_vector,rows);
																								if (ri_table[previous] <0)
																								{
																												printf("value of previous : %d %d \n",previous,rs_table[previous]);
																												getchar();
																								}
																								mint = min_intermediate_exact(matrix,row_vector,matrix[h],rows,cols,h);

																								inter =  mint + ri_table[previous]; 
																								if (inter < min) min = inter;
																								row_vector[h] = '1';

																				}
																}
																ri_table[sequence[iter]] = min;

												}
								}
								else
								{
												rs_table[sequence[iter]] = 0;
												ri_table[sequence[iter]] = 0;

												//backtrack[sequence[iter]] = 0;
												// printf(" rs_table[%d] : %d \n",sequence[iter], rs_table[sequence[iter]]);
												// getchar();
								}
				}
				int recombs = ri_table[sequence[size-1]];
				free(sequence); free(rs_table); free(ri_table); free(row_vector);

				return recombs;

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


int new_ri_bound(char** matrix, int rows,int cols )
{
				if (rows > 20 ) // maximum number of rows allowed is 20 
								return 0;
				int size = pow(2,rows);
				int current = 0, i=0;
				int* sequence = (int*)malloc(sizeof(int)*size);
				int* rd_table = (int*)malloc(sizeof(int)*size);
				int* ri_table = (int*)malloc(sizeof(int)*size);
				//int* backtrack = new int[size]; // for each entry in the rs table where does it point to in backtracking 
				for (i=0;i<size;i++)
				{
								rd_table[i] = 0;
								ri_table[i] = 0;
				}
				length = rows;
				int* string;

				for (i = 0; i <= rows; i++)
				{
								string = (int*)malloc(sizeof(int)*rows);
								generate(string, 0, i, sequence, &current);
								free(string);
				}
				printf("  table size: %d \n",size);

				char* row_vector = (char*)malloc(rows);
				for (i=0;i<rows;i++) row_vector[i] = '0';
				int red_row ;
				int selected =0;
				int previous;
				int min,max,min_rd;
				int h;
				int best,  r=0,mint=0;
				int rcount = 0;
				int last, inter, iter=0;

				for(iter=1;iter<size;iter++)
				{
								//   printf("iter: %d %d\n",iter,sequence[iter]);
								init_vector(row_vector,sequence[iter],rows,&selected);

								if (selected >3)
								{ 
												red_row = redundant_row(matrix,rows,cols,row_vector,'u');

												//     printf("red_row: %d \n",red_row);
												if (red_row != -1)
												{
																row_vector[red_row] = '0';
																previous = convert(row_vector,rows);
																// for (h=0;h<rows;h++)
																//    printf("%c ",row_vector[h]);
																// printf("\n\n");
																if (rd_table[previous] <0)
																{
																				printf("value of previous : %d %d \n",previous,rd_table[previous]);//getchar();
																}
																rd_table[sequence[iter]] = rd_table[previous];
																ri_table[sequence[iter]] = ri_table[previous];
												}
												else if (red_row == -1)
												{
																// modified code for computing R_d 
																min_rd = INFTY;
																best =0;
																min = INFTY;
																rcount = 0;
																max =0;
																for (r= 0;r<rows;r++)
																				if (row_vector[r] == '1')
																								rcount++;

																for (h=0;h<rows;h++)
																{
																				if (row_vector[h] == '1') // for all rows that are 1
																				{
																								row_vector[h] = '0';
																								previous = convert(row_vector,rows);
																								if (rd_table[previous] <0)
																								{
																												printf("value of previous : %d %d \n",previous,rd_table[previous]);
																												getchar();
																								}

																								if (is_different_hap(matrix,row_vector,matrix[h],rows,cols) == 1)
																								{
#ifdef DEBUG
																												if (rcount > 5)
																												{
																																printf(" there is a nicolumn : \n row vector: ");
																																for (r=0;r<rows;r++)
																																				printf("%c ",row_vector[r]);
																																printf("\n\n");
																												}
#endif
																												if (rd_table[previous] < min_rd)
																																min_rd = rd_table[previous];
																								}

																								else 
																								{	
																												if (rd_table[previous] + 1 < min_rd)
																																min_rd = rd_table[previous] + 1; // big bumble !!!!!!!!!!!!!11

																								}
																								// code for computing R_I
																								// R_I,i = max { (1 + R_I(r-i)), I_i(r-i) + R_d (r-i)}  
																								// ri(r) = min_i  R_I,i

																								last = 1 + ri_table[previous];
																								inter =  min_intermediate_exact(matrix,row_vector,matrix[h],rows,cols,h) + rd_table[previous]; 

																								if (last > inter) max = last; 
																								else  max = inter;

																								if (max < min)
																								{
																												min = max;
																								}
																								row_vector[h] = '1';
																				}
																}
																rd_table[sequence[iter]] = min_rd;
																ri_table[sequence[iter]] = min;

												}
								}
								else
								{
												rd_table[sequence[iter]] = 0;
												ri_table[sequence[iter]] = 0;
								}
				}
				int recombs = ri_table[sequence[size-1]];
				free(sequence); free(rd_table); free(ri_table); free(row_vector);
				printf("%d \t",recombs);

				return recombs;
}


int ri_bound(char** matrix, int rows,int cols )
{

				if (rows > 20 ) // maximum number of rows allowed is 20 
								return 0;

				// rows = 5;
#ifdef DEBUG
				printf("rows: %d \n",rows);
#endif
				//getchar();
				int size = pow(2,rows);
				// declare table of size 2^rows
				int* sequence = (int*)malloc(sizeof(int)*size);
				int* rs_table = (int*)malloc(sizeof(int)*size);
				int* ri_table = (int*)malloc(sizeof(int)*size);
				int i=0,current =0;
				//int* backtrack = new int[size]; // for each entry in the rs table where does it point to in backtracking 
				for (i=0;i<size;i++)
				{
								rs_table[i] = 0;
								ri_table[i] = 0;
				}
#ifdef DEBUG
				printf("  table size: %d \n",size);
#endif
				current = 0;
				length = rows;
				int* string;

				for (i = 0; i <= rows; i++)
				{
								string = (int*)malloc(sizeof(int)*rows);
								generate(string, 0, i, sequence, &current);
								free(string);
				}
				// printf("  table size: %d \n",size);

				char* row_vector = (char*)malloc(rows);
				for (i=0;i<rows;i++)
								row_vector[i] = '0';
				int red_row ;
				int selected =0;
				int previous;
				int min,max;
				int h;
				int best;
				int last,  inter, iter=0; int mint=0;

				for(iter=1;iter<size;iter++)
				{
								//   printf("iter: %d %d\n",iter,sequence[iter]);
								init_vector(row_vector,sequence[iter],rows,&selected);

								if (selected >3)
								{ 
												red_row = redundant_row(matrix,rows,cols,row_vector,'u');

												//     printf("red_row: %d \n",red_row);
												if (red_row != -1)
												{
																row_vector[red_row] = '0';
																previous = convert(row_vector,rows);
																// for (h=0;h<rows;h++)
																//    printf("%c ",row_vector[h]);
																// printf("\n\n");
																if (rs_table[previous] <0)
																{
																				printf("value of previous : %d %d \n",previous,rs_table[previous]);
																				//getchar();

																}
																rs_table[sequence[iter]] = rs_table[previous];
																ri_table[sequence[iter]] = ri_table[previous];
																//backtrack[sequence[iter]] = previous;
																// no recombination
																//     printf(" red row: %d no recomb %d  %d \n",red_row,rs_table[sequence[iter]],previous); 
												}
												else if (red_row == -1)
												{
																min = INFTY;
																best =0;

																for (h=0;h<rows;h++)
																{
																				if (row_vector[h] == '1')
																				{
																								row_vector[h] = '0';
																								previous = convert(row_vector,rows);
																								if (rs_table[previous] <0)
																								{
																												printf("value of previous : %d %d \n",previous,rs_table[previous]);
																												getchar();
																								}
																								if (rs_table[previous] < min)
																								{
																												min = rs_table[previous];
																												best = previous;
																								}
																								row_vector[h] = '1';

																				}
																}
																//printf(" value of min :%d\n",min);
																rs_table[sequence[iter]] = min +1;
																//backtrack[sequence[iter]] = best;
																// recombination add 1 
																// min _h R_s(H-h)
																//                printf(" need to add recomb %d  \n",rs_table[sequence[iter]]);
																//if (rs_table[sequence[iter]] > 2)
																//getchar();
																// code for updating r_i

																best =0;
																min = INFTY;
																mint=0;
																// R_I,i = max { (1 + R_I(r-i)), I_i(r-i) + R_s (r-i)}  
																// ri(r) = min_i  R_I,i
																for (h=0;h<rows;h++)
																{
																				if (row_vector[h] == '1')
																				{
																								row_vector[h] = '0';
																								previous = convert(row_vector,rows);
																								if (ri_table[previous] <0)
																								{
																												printf("value of previous : %d %d \n",previous,rs_table[previous]);
																												getchar();
																								}

																								last = 1 + ri_table[previous];
																								mint = 1;
																								//	printf(" calling min inter function %d \n\n",mint);
																								mint = min_intermediate_exact(matrix,row_vector,matrix[h],rows,cols,h);
																								//if (mint > 8)	printf(" returned by the min inter function %d \n\n",mint);

																								//inter =  mint + rs_table[previous]; 
																								inter =  mint ;  // changed here 

																								if (last > inter) max = last; 
																								else 
																								{
																												max = inter;
																								}
																								if (max < min)
																								{
																												min = max;
																								}
																								row_vector[h] = '1';


																				}
																}
																ri_table[sequence[iter]] = min;

												}
								}
								else
								{
												rs_table[sequence[iter]] = 0;
												ri_table[sequence[iter]] = 0;

												//backtrack[sequence[iter]] = 0;
												// printf(" rs_table[%d] : %d \n",sequence[iter], rs_table[sequence[iter]]);
												// getchar();
								}
				}
				int recombs = ri_table[sequence[size-1]];

				free(sequence); free(rs_table); free(ri_table); free(row_vector);
				return recombs;

}


int test_cover_greedy(char** matrix, int n, int m)
{
				// also works on matrix with missing data: just ignore the discriminating power of missing entries
				// find a greedy test cover for the matrix and return (diversity - |test cover| -1)
				int r = n*(n-1); r = r/2;
				int c = m;
				int counter = 0;
				int i=0,j=0,k=0, nc=0,cv=0;

				int missing_entries=0;
				for (i=0;i<n;i++) { for (	j=0;j<m;j++) { if(matrix[i][j] == '?' || matrix[i][j]=='-') missing_entries++;}}

				char* col_vector = (char*)malloc(c);
				char** A = (char**)malloc(sizeof(char*)*r);
				for (i=0;i<r;i++)
				{
								A[i] = (char*)malloc(c);
								for (j=0;j<c;j++)
												A[i][j] ='0';
				}

				for (i=0;i<c;i++)
				{
								counter = 0;
								for (j=0;j<n-1;j++)
								{
												for (k=j+1;k<n;k++)
												{
																if (matrix[j][i] != matrix[k][i] && matrix[k][i] != '?' && matrix[j][i] != '?'
																								&& matrix[k][i] != '-' && matrix[j][i] != '-') // takes care of missing data
																				A[counter][i] = '1';
																else A[counter][i] = '0';
																counter++;

												}
								}
				}

				// lets maintain a list of the columns with an entry which is the number of rows that a columns covers currently
				// this is updated when we choose a column to be included in the test cover

				// when we update, in one pass we can also extract the next best column
				int* rows_covered = (int*)malloc(sizeof(int)*c);
				int flag =0,best_col=0,test_cover =0;

				// the solution returned is a set of columns choosen to be in the test cover
				for (cv = 0;cv<c;cv++) col_vector[cv] = '0';

				for (i=0;i<c;i++)
				{
								nc = 0;
								for (j=0;j<r;j++)
								{
												if (A[j][i] == '1')
																nc++;
								}
								rows_covered[i] = nc;
				}
				while (flag ==0)
				{
								best_col = 0;
								for (i=0;i<c;i++)
								{
												//		printf("pairs covered by col %d is %d \n",i,rows_covered[i]);
												if (rows_covered[i] > rows_covered[best_col])
																best_col = i;
								}
								if (rows_covered[best_col] ==0)
								{
												flag =1;break;
								}
								else 
								{	
												test_cover++;	col_vector[best_col] = '1'; // put the column choosen to be in the test cover 
								}

								// set all entries in a row which has a 1 in the best_col to be zero 
								// best_col is the best column to choose in the next iteration

								for (i=0; i<r;i++)
								{
												if (A[i][best_col] == '1')
												{
																for (j=0;j<c;j++)
																				if  (A[i][j] == '1')
																				{
																								rows_covered[j]--;
																								A[i][j] = '0';
																				}
												}
								}
				}

				int r_h = n-test_cover -1; int ri=0; int it=0;
				// copy the submatrix in the columns of the test cover and find a solution to the MHC problem for this submatrix if 
				// it has missing entries else return the difference of the rows and (columns + 1)
				// copy the columns to this new matrix

				char** red_matrix = (char**)malloc(sizeof(char*)*n);
				for (it= 0;it<n;it++)		red_matrix[it] = (char*)malloc(test_cover);
				int col_counter = 0;
				for (i=0;i<c;i++)
				{
								if (col_vector[i] == '1')
								{
												for (ri = 0;ri<n;ri++)
												{
																red_matrix[ri][col_counter] = matrix[ri][i];
												}
												col_counter++;
												if (col_counter > test_cover)  printf("error flag !!!!! size of test cover is smaller \n\n");
								}
				}

				// now we can check if the matrix induced by the test cover has mosaic bound equal to the RH bound, if not the mosaic bound is not optimal
				int mb=0;
				//	if (n <14) { mb = mosaic_bound(red_matrix, n,test_cover);
				//		if (r_h < mb) { r_h++; /*printf(" the lower bound is sub-optimal, can increas by one %d %d \n",r_h,mb); getchar();*/ }
				//	}

				int a=0, b=0,alph,bet;
				int identical_pairs = 0;
				char** D_12 ;// matrix to distinguish between pair of haplotypes 

				if (missing_entries >0) {
								// find the maximum number of distinct rows in this matrix 
								D_12 = (char**)malloc(sizeof(char*)*n);// matrix to distinguish between pair of haplotypes 
								for (a=0;a<n;a++)
								{
												D_12[a] = (char*)malloc(n);
												for (b=a+1;b<n;b++)
												{
																if (b > a)
																{
																				D_12[a][b] = '0';
																				// check if the rows 'a' and 'b' are different in some column 
																				for (i=0;i<test_cover;i++)
																				{
																								if (red_matrix[a][i] != red_matrix[b][i] && red_matrix[a][i] != '?' && red_matrix[b][i] != '?' && red_matrix[a][i] != '-'
																																&& red_matrix[b][i] != '-')		
																								{
																												D_12[a][b] = '1';
																												break;
																								}
																				}

																}
																else D_12[a][b] ='0';
												}
								}
								for (a=0;a<n-1;a++) {
												for (b=a+1;b<n;b++)
												{
																if (D_12[a][b] == '0' && b >a)	identical_pairs++;
												}
								}
								if (identical_pairs != 0) printf(" some of the rows are identical bound reduced by %d \n",identical_pairs);
								for (a=0;a<n;a++) free(D_12[a]); free(D_12);
								for (a=0;a<r;a++) free(A[a]); free(A);
								free(rows_covered); free(col_vector);
								for (a= 0;a<n;a++) free(red_matrix[a]); free(red_matrix);
								return (r_h- identical_pairs);
				}

				else
				{
								for (a=0;a<r;a++) free(A[a]); free(A);
								free(rows_covered); free(col_vector);
								for (a= 0;a<n;a++) free(red_matrix[a]); free(red_matrix);
								return r_h;
				}
}


void comb_local(char** matrix, int rows, int** R, int** B, int cols, int size)
{
				int* partition_vector = (int*) malloc(sizeof(int)*cols);
				int k=1, i=0, tmp=0, j=0;
				for (i=0;i<cols;i++) partition_vector[i] = 0;
				while (k < cols)
				{
								for(j=0;j < k;j++)
								{
												if ((k -j) >= size)	i = k - size+1;
												else i =j;
												while(i<k)
												{
																tmp = R[j][i] + B[i][k];
																if (R[j][k] < tmp)
																{
																				R[j][k] = tmp; partition_vector[j] = i; // interval from j to k is split into two intervals j-i and i-k 
																}
																i++;
												}
								}
								k++;
				}

				free(partition_vector);
}


int remove_dups(char** matrix, int rows, int sc, int ec, char** nr_matrix)
{
				// remove all duplicate rows from the matrix and return them in the matrix nr_matrix
				// both these matrices are already created 
				int flag =0;
				int flag1=0;
				int j=0;
				int r1 =0;
				int i=0;
				int k=0;
				int l=0;
				for ( i=0;i<rows-1;i++)
				{
								flag =0;
								j =i+1;
								while (j<rows)
												// compare row i against all rows below it and if it does not exist then copy to it make a new row in nr_matrix
								{
												flag1=0;
												k =sc;
												while(k<ec+1) // correct !!!!!!!!!!!1  ec+1 instead of ec 
												{
																if (matrix[i][k] != matrix[j][k] && matrix[i][k] != '?' && matrix[j][k] != '?'
																								&& matrix[i][k] != '-' && matrix[j][k] != '-') // takes care of missing data
																{
																				flag1 =1;       // row i is not equal to row j 
																				k=ec+1;
																}
																k++;
												}
												j++;
												if (flag1 ==0)
												{
																//			printf(" row %d is same as row %d \n",i,j);
																flag =1;
																j = rows;
												}
								}
								if (flag==0)
								{
												// need to copy this row as it is unique 
												for (l=sc;l<ec+1;l++)
																nr_matrix[r1][l-sc] = matrix[i][l];
												r1++;
								}
				}
				// copy the last row as it is never compared 
				for (l=sc;l<ec+1;l++)
								nr_matrix[r1][l-sc] = matrix[rows-1][l];
				r1++;

				return r1;
}


int clean_redundant(char** matrix, int rows, int sc, int ec, char** nr_matrix,int* nr, int* nc)
{
				// remove all duplicate rows, non informative columns until the matrix is clean
				// also remove one of two adjacent columns if they have only 2 distinct pairs ( either identical/complementary)
				// remove all sites that have missing entries

				char* is_row = (char*)malloc(rows); char* is_col = (char*)malloc(ec-sc+1);

				int temp=0;
				for (temp=0;temp<rows;temp++) is_row[temp] = '1';
				for (temp=sc;temp<ec+1;temp++) is_col[temp-sc] = '1';
				//    conflict_free_columns(matrix, rows ,ec-sc,is_col);

				int flag =0, flag1=0;
				int i=0, j=0,k=0, l=0, r1=0;
				int ones = 0, zeros = 0;
				int cols_deleted=0, rows_deleted=0;

				//		printf(" reached here %d %d \n",sc,ec);getchar();
				int missing_entry = 0; int flag_00=0, flag_01=0,flag_10=0,flag_11=0;

				for (i=sc; i < ec;i++)
				{
								for (j = i+1;j<ec+1;j++)
								{
												flag_00=0;flag_01 = 0;flag_10 = 0;flag_11 = 0;k=0;
												while (k < rows)
												{
																if (matrix[k][i-sc] == '0' && matrix[k][j-sc] == '0')        flag_00 =1;
																if (matrix[k][i-sc] == '0' && matrix[k][j-sc] == '1')        flag_01 =1;
																if (matrix[k][i-sc] == '1' && matrix[k][j-sc] == '1')flag_11 =1;
																if (matrix[k][i-sc] == '1' && matrix[k][j-sc] == '0')flag_10 =1;
																k++;
												}
												if ( flag_00 ==1 && flag_01 == 1 && flag_10 == 1 && flag_11 == 1) { is_col[i-sc]='1'; is_col[j-sc] = '1';}
								}
				}

				// want to compute the number of distinct rows considering all SNP's
				int disrows=rows; int iter=0; int H;

				while (1)
				{
								// remove all duplicate rows from the matrix
								rows_deleted =0;
								for ( i=0;i<rows-1;i++)
								{
												if (is_row[i]=='0') continue;
												flag =0;
												j =i+1;
												while (j<rows)// compare row i against rows below & if not there, set flag = true
												{
																if (is_row[j]=='0') { j++; continue;}
																flag1=0;
																k =sc;
																while(k<ec+1)
																{
																				if ( is_col[k-sc]=='1' && matrix[i][k] != matrix[j][k])
																				{
																								flag1 =1;       // row i is not equal to row j
																								k=ec+1;
																				}
																				k++;
																}
																if (flag1 ==0)
																{
																				//printf(" row %d is same as row %d \n",i,j);
																				flag =1;
																				j = rows;
																				is_row[i] = '0'; disrows--;
																				rows_deleted = 1;
																}
																j++;
												}
								}
								if (iter==0) H = disrows;
								iter++;
								if (rows_deleted == 0) break;


								cols_deleted = 0;
								for (i=sc;i<ec+1;i++)
								{
												ones = 0;
												zeros = 0;
												if ( is_col[i-sc]	=='0') continue;
												missing_entry = 0;
												for (j=0;j<rows;j++)
												{
																if (is_row[j]=='0') continue;
																if (matrix[j][i] == '0') zeros++;
																else if (matrix[j][i] == '1') ones++;
																else if (matrix[j][i] == '-' || matrix[j][i] == '?') { missing_entry =1;}
												}
												if (zeros == 0 || zeros ==1 || ones == 0 || ones == 1 || missing_entry ==1)
												{
																is_col[i-sc] = '0';
																cols_deleted = 1; 
																//if (missing_entry ==1) {printf(" mssing col \n"); getchar();}
												}
								}
								//if (cols_deleted == 0) break;
								//for (int r=0;r<rows;r++) {
								//	for (int cr = 0;cr<ec+1;cr++) { if (is_col[cr]) printf("%c",matrix[r][cr]);}
								//	printf("\n");
								//} getchar();

								// while loop for doing the row and column deletion ends
				}

				// remove adjacent identical columns
				temp =sc;
				int adj_col = sc+1;
				int ri =0;
				int pairs[4]; int w=0; int no_pairs=0;
				while (temp < ec)
				{
								if (is_col[temp-sc]=='1')
								{
												adj_col = temp+1;
												while(is_col[adj_col-sc] == '0'&&  adj_col < ec)
												{
																adj_col++;
												}

												if(adj_col == ec)
												{
																//printf(" need toexit\n");
																break;
												}


												if (is_col[adj_col]=='1')
												{
																for (w=0;w<4;w++) pairs[w]=0;

																for (ri=0;ri<rows;ri++)
																{
																				if (is_row[ri]=='1')
																				{
																								if(matrix[ri][temp] == '0' && matrix[ri][adj_col] == '0')
																								{
																												pairs[0] = 1;
																								}
																								else if (matrix[ri][temp] == '0' && matrix[ri][adj_col] == '1')
																												pairs[1] = 1;
																								else if (matrix[ri][temp] == '1' && matrix[ri][adj_col] == '0')
																												pairs[2] = 1;

																								else if  (matrix[ri][temp] == '1' && matrix[ri][adj_col] == '1')
																												pairs[3] = 1;
																				}

																}
																// count the number of pairs
																no_pairs = pairs[0] + pairs[1] + pairs[2] + pairs[3];
																if (no_pairs < 3)
																{
																				//																	printf(" identical cols %d %d \n\n",temp,adj_col);
																				is_col[temp] = '0'; // the column temp deleted
																}

																temp = adj_col; // the next valid column

												}
								}
								else
												temp++;
				}

				int nr_rows=0,nr_cols=0, r=0,c=0;

				//		printf(" no of rows : %d\n ",rows);
				for (r=0;r<rows;r++)
				{
								if (is_row[r]=='1')
								{
												//									printf("%d ",r);
												nr_cols=0;
												for (c=sc;c<ec+1;c++)
												{
																if (is_col[c-sc]=='1')
																{
																				nr_matrix[nr_rows][nr_cols] = matrix[r][c];
																				nr_cols++;
																				//																printf("%c  ", matrix[r][c]);
																}
												}
												//							printf("\n");
												nr_rows++;
								}
				}
				//				printf("\n");
				(*nr) = 0;
				(*nc) = 0;
				for (temp=0;temp<rows;temp++) { if (is_row[temp]=='1') (*nr)++;}
				for (temp=sc;temp<ec+1;temp++) { if (is_col[temp-sc]=='1') (*nc)++;}
				//			printf(" \n\nno of distinct rows: %d cols: %d \n\n",(*nr),(*nc));

				//		for ( r=0;r<(*nr);r++)
				//	{
				//				for(c=0;c<(*nc);c++)
				//			{
				//								printf("%c",nr_matrix[r][c]);
				//				}
				//				printf("\n");
				//		}
				free(is_row); free(is_col);
				return H;
}


int conflict_free_columns(char** matrix, int rows ,int cols,char* is_col)
{
				printf(" inside conflcit graph fun %d %d \n",rows,cols);
				int i=0,k=0,j=0;
				for (i=0;i<cols;i++)
				{
								if (matrix[0][i] == '1')
								{
												matrix[0][i] = '0';
												for (j=1;j<rows;j++)
												{
																if (matrix[j][i] == '1')	matrix[j][i] = '0';
																else matrix[j][i] = '1';
												}
								}
				}

				int flag_01 = 0,flag_10=0,flag_11=0;
				int** conflict = (int**)malloc(sizeof(int*)*cols);
				for (i=0;i<cols;i++)
				{
								conflict[i] = (int*)malloc(cols*sizeof(int));
								for (j=0;j<cols;j++)	conflict[i][j] = 0;
				}

				for (i=0; i < cols-1;i++)
				{
								for (j = i+1;j<cols;j++)
								{
												flag_01 = 0;flag_10 = 0;flag_11 = 0;k=0;
												while (k < rows)
												{
																if (matrix[k][i] == '0' && matrix[k][j] == '1')			flag_01 =1;
																else if (matrix[k][i] == '1' && matrix[k][j] == '1')flag_11 =1;
																else if (matrix[k][i] == '1' && matrix[k][j] == '0')flag_10 =1;
																if (flag_01 == 1 && flag_10 == 1 && flag_11 == 1)	break;
																k++;
												}
												if (flag_01 == 1 && flag_10 == 1 && flag_11 == 1)	conflict[i][j] = conflict[j][i] = 1;
								}
				}
				// find the sites which are not involved in any conflict 
				int count = 0;
				int* conflict_free = (int*)malloc(cols*sizeof(int));
				int non_conflicting =0;
				int no_conn_comps = 0;
				int no_non_trivial_cc =0;
				for (i=0;i<cols;i++)
				{
								count = 0;
								for (j= 0;j<cols;j++)
								{
												if (conflict[i][j] ==1) count++;
								}
								if (count > 0) conflict_free[i] =0;
								else
								{
												conflict_free[i] = 1;
												non_conflicting++;
								}
				}
				for (i=0;i<cols;i++) { if (conflict_free[i] ==1) is_col[i] ='0'; }

				free(conflict_free);
				for (i=0;i<cols;i++)free(conflict[i]); free(conflict);
}



void compute_bounds(char* inputfile, int width)
{
				int lb,ub,disrows, RM, usefulsites;

				int rows; int cols=0;
				FILE* df = fopen(inputfile,"r");
				fscanf(df,"%d %d \n",&rows,&cols);
				fprintf(stdout,"rows %d cols %d \n",rows,cols);
				char** dm = (char**)malloc( sizeof(char*)*rows);
				int i=0,j=0;
				for (i=0;i<rows;i++) dm[i] = (char*) malloc(cols);
				for (i=0;i<rows;i++) {
								for (j=0;j<cols;j++) fscanf(df,"%c",&dm[i][j]);
								fscanf(df,"\n");
								fprintf(stdout,"%s \n",dm[i]);
				}
				process_matrix(dm,rows,cols,width,"rh",&lb,&ub,&disrows,&RM,&usefulsites); 
				for (j=0;j<rows;j++) free(dm[j]); free(dm);
				exit(0);
}

int main (int argc, char** argv)
{

				if (argc<5) { printf("\n Usage: ./LUBOUND -w width -f haplotypedatafile -s SNPlocationsfile\n\n -w width (the maximum window size for which local recombination bounds are computed) \n -f haplotypedatafile (contains the haplotypes in 0/1 format) \n  Format of input file: first line contains number of rows and number of columns, each haplotype is represented by a string on a new line \n -s SNPlocationsfile (contains the number of SNP's along with their locations on the chromosome, this is optional and currently unused)\n\n"); exit(0);}
				int width = 20;
				char hapfile[100];
				char snplocs[100];
				char** matrix;
				int rows,cols;
				int i=0;
				FILE *hf, *sf;

				for(i=1;i<argc-1;i++)
				{
								if (strcmp(argv[i],"-w")==0)
								{
												width = atoi(argv[i+1]);
												i++;
								}
								else if (strcmp(argv[i],"-f")==0)
								{
												strcpy(hapfile,argv[i+1]);
												i++;
								}
								else if (strcmp(argv[i],"-s")==0)
								{
												strcpy(snplocs,argv[i+1]);
												i++;
								}
				}

				hf = fopen(hapfile,"r");
				if (hf == NULL) {fprintf(stdout,"the haplotype data file does not exist \n\n"); exit(0);}
				else 
				{
						fprintf(stdout,"haplotype data file: %s \n",hapfile);
						fprintf(stdout,"COMPUTING Lower bounds for the data \n\n");
						compute_bounds(hapfile,width);
				}


}
